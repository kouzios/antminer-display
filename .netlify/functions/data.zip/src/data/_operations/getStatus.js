module.exports = async (index) => {
    // const res = await fetch("http://192.168.1.65/cgi-bin/minerStatus.cgi");
    // const statusInfo = await res.json();
    // return statusInfo;
    return {"hi":"bye"}
}
